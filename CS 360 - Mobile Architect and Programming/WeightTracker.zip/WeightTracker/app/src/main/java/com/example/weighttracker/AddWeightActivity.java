package com.example.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Handles weight entry, database storage, and optional SMS alerts.
public class AddWeightActivity extends AppCompatActivity {

    // Provides access to the application's database.
    private DatabaseHelper databaseHelper;

    // Stores the ID of the currently logged-in user.
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display and loads the screen layout.
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_weight);

        // Retrieves the logged-in user's ID from the previous screen.
        userId = getIntent().getLongExtra("USER_ID", -1);

        // Initializes the database helper for saving weight entries.
        databaseHelper = new DatabaseHelper(this);

        // Connects the input fields to their layout elements.
        EditText dateEditText = findViewById(R.id.dateEditText);
        EditText weightEditText = findViewById(R.id.weightEditText);
        EditText goalWeightEditText =
                findViewById(R.id.goalWeightEditText);
        EditText phoneNumberEditText =
                findViewById(R.id.phoneNumberEditText);

        // Connects the save and back buttons.
        Button saveWeightButton = findViewById(R.id.saveWeightButton);
        Button backToHistoryButton =
                findViewById(R.id.backToHistoryButton);

        // Runs the following code when the user saves a weight entry.
        saveWeightButton.setOnClickListener(v -> {

            // Retrieves the entered values and removes extra whitespace.
            String date = dateEditText.getText().toString().trim();
            String weightText =
                    weightEditText.getText().toString().trim();
            String goalText =
                    goalWeightEditText.getText().toString().trim();
            String phoneNumber =
                    phoneNumberEditText.getText().toString().trim();

            // Checks that all required fields have been filled in.
            if (date.isEmpty() || weightText.isEmpty()
                    || goalText.isEmpty()) {
                Toast.makeText(this,
                        "Enter a date, weight, and goal weight.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Prevents saving an entry without a valid login session.
            if (userId <= 0) {
                Toast.makeText(this,
                        "Your login session is missing. Please log in again.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Variables used to store the numeric weight values.
            double currentWeight;
            double goalWeight;

            try {
                // Converts the text entered by the user into numbers.
                currentWeight = Double.parseDouble(weightText);
                goalWeight = Double.parseDouble(goalText);

            } catch (NumberFormatException e) {
                // Displays an error if either value is not a valid number.
                Toast.makeText(this,
                        "Enter valid numbers for both weights.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Makes sure both weights are valid, finite, and greater than zero.
            if (!Double.isFinite(currentWeight)
                    || !Double.isFinite(goalWeight)
                    || currentWeight <= 0 || goalWeight <= 0) {
                Toast.makeText(this,
                        "Weights must be positive, valid numbers.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Saves the weight entry under the logged-in user's account.
            // SMS notifications are handled separately after saving.
            boolean saved = databaseHelper.addWeight(
                    userId, date, currentWeight, goalWeight);

            // Stops the process if the database could not save the entry.
            if (!saved) {
                Toast.makeText(this,
                        "Could not save. Check the date for an existing entry.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Confirms that the weight entry was saved successfully.
            Toast.makeText(this,
                    "Weight entry saved successfully.",
                    Toast.LENGTH_SHORT).show();

            // Checks whether the user has reached or passed their goal.
            // Sends an SMS alert only if the current weight is at or
            // below the goal weight.
            if (currentWeight <= goalWeight) {
                sendGoalReachedSms(phoneNumber);
            }

            // Returns to the weight history screen after saving.
            Intent intent = new Intent(
                    AddWeightActivity.this,
                    WeightHistoryActivity.class);

            // Passes the user's information to preserve the login session.
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME",
                    getIntent().getStringExtra("USERNAME"));

            startActivity(intent);

            // Closes the add weight screen.
            finish();
        });

        // Returns to the weight history screen without saving a new entry.
        backToHistoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    AddWeightActivity.this,
                    WeightHistoryActivity.class);

            // Preserves the user's information when navigating back.
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME",
                    getIntent().getStringExtra("USERNAME"));

            startActivity(intent);
            finish();
        });

        // Adjusts screen padding so content does not overlap
        // the device's status bar or navigation bar.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);

                    return insets;
                });
    }

    // Sends an SMS alert when the user reaches their goal weight.
    private void sendGoalReachedSms(String phoneNumber) {

        // Checks whether the app has permission to send SMS messages.
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Allows weight tracking to continue without SMS permission.
            Toast.makeText(this,
                    "Weight saved. Enable SMS permission for alerts.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Checks that a phone number was entered before sending the alert.
        if (phoneNumber.isEmpty()) {
            Toast.makeText(this,
                    "Weight saved. Enter a phone number to receive SMS alerts.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        try {
            // Gets the Android SMS manager to send a text message.
            SmsManager smsManager = SmsManager.getDefault();

            // Sends a congratulatory message to the entered phone number.
            smsManager.sendTextMessage(
                    phoneNumber, null,
                    "Congratulations! You have reached your goal weight.",
                    null, null);

            // Confirms that Android accepted the SMS send request.
            Toast.makeText(this,
                    "Goal-reached SMS sent.",
                    Toast.LENGTH_SHORT).show();

        } catch (SecurityException | IllegalArgumentException e) {
            // Handles permission or phone number errors during sending.
            Toast.makeText(this,
                    "Weight saved, but the SMS could not be sent.",
                    Toast.LENGTH_LONG).show();
        }
    }

    // Closes the database helper when the activity is destroyed.
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}