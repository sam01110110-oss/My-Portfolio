package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// Manages the application's persistent SQLite database.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // User account table.
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";

    // Weight history table.
    private static final String TABLE_WEIGHTS = "weight_entries";
    private static final String COL_WEIGHT_ID = "id";
    private static final String COL_WEIGHT_USER_ID = "user_id";
    private static final String COL_DATE = "entry_date";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_GOAL_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Each username must be unique.
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT NOT NULL COLLATE NOCASE UNIQUE, " +
                COL_PASSWORD_HASH + " TEXT NOT NULL)");

        // Each weight entry belongs to a user account.
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                COL_DATE + " TEXT NOT NULL, " +
                COL_WEIGHT + " REAL NOT NULL, " +
                COL_GOAL_WEIGHT + " REAL NOT NULL, " +
                "UNIQUE(" + COL_WEIGHT_USER_ID + ", " +
                COL_DATE + "), " +
                "FOREIGN KEY(" + COL_WEIGHT_USER_ID + ") " +
                "REFERENCES " + TABLE_USERS + "(" +
                COL_USER_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        // Future database schema changes will be handled here.
    }

    // Hashes passwords before storing them.
    private String hashPassword(String password) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(
                    password.getBytes(java.nio.charset.StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b & 0xff));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(
                    "Password hashing is unavailable.", e);
        }
    }

    // Creates a new account if the username is available.
    public boolean registerUser(String username, String password) {
        if (username == null || password == null ||
                username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username.trim());
        values.put(COL_PASSWORD_HASH, hashPassword(password));

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Checks the supplied credentials against the database.
    public boolean validateUser(String username, String password) {
        if (username == null || password == null) {
            return false;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ? AND " +
                        COL_PASSWORD_HASH + " = ?",
                new String[]{username.trim(), hashPassword(password)},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    // Returns the database ID associated with a username.
    public long getUserId(String username) {
        if (username == null) {
            return -1;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ?",
                new String[]{username.trim()},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }
        return -1;
    }

    // Adds a weight entry. The date must be unique per user.
    public boolean addWeight(long userId, String date,
                             double weight, double goalWeight) {
        if (userId <= 0 || date == null || date.trim().isEmpty()
                || weight <= 0 || goalWeight <= 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_USER_ID, userId);
        values.put(COL_DATE, date.trim());
        values.put(COL_WEIGHT, weight);
        values.put(COL_GOAL_WEIGHT, goalWeight);

        return getWritableDatabase().insert(
                TABLE_WEIGHTS, null, values) != -1;
    }

    // Updates an existing weight entry.
    public boolean updateWeight(long weightId, String date,
                                double weight, double goalWeight) {
        if (weightId <= 0 || date == null || date.trim().isEmpty()
                || weight <= 0 || goalWeight <= 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COL_DATE, date.trim());
        values.put(COL_WEIGHT, weight);
        values.put(COL_GOAL_WEIGHT, goalWeight);

        return getWritableDatabase().update(
                TABLE_WEIGHTS, values, COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(weightId)}) > 0;
    }

    // Deletes a weight entry.
    public boolean deleteWeight(long weightId) {
        if (weightId <= 0) {
            return false;
        }

        return getWritableDatabase().delete(
                TABLE_WEIGHTS, COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(weightId)}) > 0;
    }

    // Retrieves weight entries for a specific user, newest first.
    public Cursor getWeightsForUser(long userId) {
        return getReadableDatabase().query(
                TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID, COL_DATE,
                        COL_WEIGHT, COL_GOAL_WEIGHT},
                COL_WEIGHT_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null, COL_DATE + " DESC");
    }
}