package com.example.weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Displays and manages the logged-in user's weight history.
public class WeightHistoryActivity extends AppCompatActivity {

    // Stores the logged-in user's ID and username.
    private long userId;
    private String username;

    // Provides access to the application's database.
    private DatabaseHelper databaseHelper;

    // References the table and text fields displayed on the screen.
    private TableLayout weightHistoryTable;
    private TextView currentWeightTextView;
    private TextView goalWeightTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display and loads the screen layout.
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight_history);

        // Gets the user's information passed from the previous screen.
        userId = getIntent().getLongExtra("USER_ID", -1);
        username = getIntent().getStringExtra("USERNAME");

        // Initializes the database helper and connects the screen elements.
        databaseHelper = new DatabaseHelper(this);
        weightHistoryTable = findViewById(R.id.weightHistoryTable);
        currentWeightTextView =
                findViewById(R.id.currentWeightTextView);
        goalWeightTextView =
                findViewById(R.id.goalWeightTextView);

        // Connects the navigation buttons to their corresponding actions.
        Button addWeightButton = findViewById(R.id.addWeightButton);
        Button notificationsButton =
                findViewById(R.id.notificationsButton);
        Button backToLoginButton =
                findViewById(R.id.backToLoginButton);

        // Opens the screen for adding a weight entry.
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, AddWeightActivity.class);

            // Passes the user's information to the next screen.
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
        });

        // Opens the SMS notification settings screen.
        notificationsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    WeightHistoryActivity.this,
                    NotificationsActivity.class);

            // Keeps the user information available on the next screen.
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME", username);

            startActivity(intent);
        });

        // Returns to the login screen and closes this activity.
        backToLoginButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        // Adjusts the screen padding to prevent content from
        // overlapping the device's system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets bars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    v.setPadding(bars.left, bars.top,
                            bars.right, bars.bottom);
                    return insets;
                });
    }

    // Reloads the weight history whenever the screen becomes visible.
    @Override
    protected void onResume() {
        super.onResume();

        // Only load records when the database and user ID are available.
        if (databaseHelper != null && userId > 0) {
            loadWeightHistory();
        }
    }

    // Retrieves the user's weight records and displays them in the table.
    private void loadWeightHistory() {

        // Remove the XML sample row and previously generated rows.
        if (weightHistoryTable.getChildCount() > 1) {
            weightHistoryTable.removeViews(
                    1, weightHistoryTable.getChildCount() - 1);
        }

        // Resets the displayed values before loading updated information.
        currentWeightTextView.setText("Current Weight: --");
        goalWeightTextView.setText("Goal Weight: --");

        try (Cursor cursor =
                     databaseHelper.getWeightsForUser(userId)) {

            // Identifies the first record to display the latest weight
            // and goal at the top of the screen.
            boolean firstEntry = true;

            // Processes each weight record returned by the database.
            while (cursor.moveToNext()) {

                // Reads the record ID, date, weight, and goal weight.
                long weightId = cursor.getLong(
                        cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("entry_date"));
                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight"));
                double goal = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("goal_weight"));

                // Uses the first record to update the summary at the top.
                if (firstEntry) {
                    currentWeightTextView.setText(
                            "Current Weight: " + weight + " lbs");
                    goalWeightTextView.setText(
                            "Goal Weight: " + goal + " lbs");
                    firstEntry = false;
                }

                // Adds the record and its action buttons to the table.
                addHistoryRow(weightId, date, weight, goal);
            }
        } catch (Exception e) {
            // Informs the user if the history cannot be retrieved.
            Toast.makeText(this,
                    "Unable to load weight history.",
                    Toast.LENGTH_LONG).show();
        }
    }

    // Creates a table row containing a weight entry and its action buttons.
    private void addHistoryRow(long weightId, String date,
                               double weight, double goal) {
        TableRow row = new TableRow(this);

        // Creates cells to display the date and recorded weight.
        TextView dateView = createCell(date);
        TextView weightView = createCell(weight + " lbs");

        // Creates an edit button for updating the selected record.
        Button editButton = new Button(this);
        editButton.setText("EDIT");
        editButton.setTextSize(11);
        editButton.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.rgb(76, 175, 80)));

        // Opens the edit dialog with the record's current information.
        editButton.setOnClickListener(v ->
                showEditDialog(weightId, date, weight, goal));

        // Creates a delete button for removing the selected record.
        Button deleteButton = new Button(this);
        deleteButton.setText("DELETE");
        deleteButton.setTextSize(11);
        deleteButton.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.rgb(76, 175, 80)));

        // Requests confirmation before attempting to delete the record.
        deleteButton.setOnClickListener(v ->
                confirmDelete(weightId));

        // Adds the date, weight, and buttons to the row.
        row.addView(dateView, cellParams());
        row.addView(weightView, cellParams());
        row.addView(editButton, cellParams());
        row.addView(deleteButton, cellParams());

        // Adds the completed row to the weight history table.
        weightHistoryTable.addView(row);
    }

    // Creates a formatted text cell for displaying table information.
    private TextView createCell(String text) {
        TextView cell = new TextView(this);

        cell.setText(text);
        cell.setTextColor(android.graphics.Color.WHITE);
        cell.setTextSize(13);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(2, 8, 2, 8);

        return cell;
    }

    // Gives each table cell equal space within its row.
    private TableRow.LayoutParams cellParams() {
        return new TableRow.LayoutParams(
                0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
    }

    // Allows the user to edit an existing weight entry.
    private void showEditDialog(long weightId, String oldDate,
                                double oldWeight, double oldGoal) {

        // Creates a vertical layout to hold the editing fields.
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 8, 32, 8);

        // Creates a date field and fills it with the existing date.
        EditText dateInput = new EditText(this);
        dateInput.setHint("Date");
        dateInput.setSingleLine(true);
        dateInput.setText(oldDate);
        layout.addView(dateInput);

        // Creates a weight field that accepts decimal numbers.
        EditText weightInput = new EditText(this);
        weightInput.setHint("Weight in lbs");
        weightInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
                        | InputType.TYPE_NUMBER_FLAG_DECIMAL
                        | InputType.TYPE_NUMBER_FLAG_SIGNED);
        weightInput.setText(String.valueOf(oldWeight));
        layout.addView(weightInput);

        // Creates a goal weight field with the existing goal.
        EditText goalInput = new EditText(this);
        goalInput.setHint("Goal weight in lbs");
        goalInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
                        | InputType.TYPE_NUMBER_FLAG_DECIMAL
                        | InputType.TYPE_NUMBER_FLAG_SIGNED);
        goalInput.setText(String.valueOf(oldGoal));
        layout.addView(goalInput);

        // Builds a dialog that lets the user cancel or save changes.
        new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(layout)

                // Closes the dialog without saving changes.
                .setNegativeButton("Cancel", (dialog, which) -> {
                })

                // Validates the entered information before updating the database.
                .setPositiveButton("Save", (dialog, which) -> {
                    String date = dateInput.getText()
                            .toString().trim();

                    try {
                        // Converts the entered weight values into numbers.
                        double weight = Double.parseDouble(
                                weightInput.getText().toString().trim());
                        double goal = Double.parseDouble(
                                goalInput.getText().toString().trim());

                        // Rejects empty dates, nonpositive weights,
                        // and invalid numeric values.
                        if (date.isEmpty() || weight <= 0 || goal <= 0
                                || !Double.isFinite(weight)
                                || !Double.isFinite(goal)) {
                            Toast.makeText(this,
                                    "Enter a valid date and positive weights.",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }

                        // Updates the selected record in the database.
                        boolean updated = databaseHelper.updateWeight(
                                weightId, date, weight, goal);

                        if (updated) {
                            // Confirms the update and refreshes the table.
                            Toast.makeText(this,
                                    "Weight entry updated.",
                                    Toast.LENGTH_SHORT).show();
                            loadWeightHistory();
                        } else {
                            // Reports a failed update, possibly caused
                            // by another entry using the same date.
                            Toast.makeText(this,
                                    "Update failed. The date may already exist.",
                                    Toast.LENGTH_LONG).show();
                        }

                    } catch (NumberFormatException e) {
                        // Handles values that cannot be converted to numbers.
                        Toast.makeText(this,
                                "Enter valid weight numbers.",
                                Toast.LENGTH_LONG).show();

                    } catch (Exception e) {
                        // Handles other errors during the update process.
                        Toast.makeText(this,
                                "Could not update the entry.",
                                Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    // Asks the user to confirm before deleting a weight entry.
    private void confirmDelete(long weightId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry")
                .setMessage("Are you sure you want to delete this entry?")

                // Closes the dialog without deleting the record.
                .setNegativeButton("Cancel", (dialog, which) -> {
                })

                // Deletes the selected record after confirmation.
                .setPositiveButton("Delete", (dialog, which) -> {
                    try {
                        boolean deleted =
                                databaseHelper.deleteWeight(weightId);

                        if (deleted) {
                            // Confirms deletion and refreshes the table.
                            Toast.makeText(this,
                                    "Weight entry deleted.",
                                    Toast.LENGTH_SHORT).show();
                            loadWeightHistory();
                        } else {
                            // Reports that the database did not delete the record.
                            Toast.makeText(this,
                                    "Could not delete the entry.",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        // Notifies the user if a deletion error occurs.
                        Toast.makeText(this,
                                "An error occurred while deleting.",
                                Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    // Closes the database helper when this screen is destroyed.
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}