package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Handles login and account creation.
public class MainActivity extends AppCompatActivity {

    // References to the username and password input fields.
    private EditText usernameEditText;
    private EditText passwordEditText;

    // Provides access to the account database.
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize the database and login fields.
        databaseHelper = new DatabaseHelper(this);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton =
                findViewById(R.id.createAccountButton);

        // Validate existing users before opening weight history.
        loginButton.setOnClickListener(v -> loginUser());

        // Save a new account when the user requests one.
        createAccountButton.setOnClickListener(v -> createAccount());

        // Preserve edge-to-edge system bar spacing.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);
                    return insets;
                });
    }

    // Validates the user's credentials and opens weight history.
    private void loginUser() {
        // Read the input fields and remove extra spaces from the username.
        String username = usernameEditText.getText()
                .toString().trim();
        String password = passwordEditText.getText()
                .toString();

        // Require both fields before checking the database.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Enter your username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.validateUser(username, password)) {
            // Pass the account ID to the weight history screen.
            long userId = databaseHelper.getUserId(username);

            Intent intent = new Intent(
                    MainActivity.this, WeightHistoryActivity.class);
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
        } else {
            // Inform the user if the credentials do not match.
            Toast.makeText(this,
                    "Invalid username or password. Please try again.",
                    Toast.LENGTH_LONG).show();
        }
    }

    // Validates the registration information and creates a new account.
    private void createAccount() {
        // Read the username and password entered by the user.
        String username = usernameEditText.getText()
                .toString().trim();
        String password = passwordEditText.getText()
                .toString();

        // Do not allow registration with missing information.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Enter a username and password to create an account.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Require a password with at least eight characters.
        if (password.length() < 8) {
            Toast.makeText(this,
                    "Password must be at least 8 characters.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Save the new account through the database helper.
        if (databaseHelper.registerUser(username, password)) {
            // Confirm successful registration and clear the password field.
            Toast.makeText(this,
                    "Account created! You can now log in.",
                    Toast.LENGTH_LONG).show();
            passwordEditText.setText("");
        } else {
            // Registration may fail if the username already exists.
            Toast.makeText(this,
                    "Could not create account. That username may already exist.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Close the database helper when this activity is destroyed.
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}