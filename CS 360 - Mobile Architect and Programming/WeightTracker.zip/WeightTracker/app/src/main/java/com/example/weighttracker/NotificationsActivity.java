package com.example.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Manages SMS permission and displays its current status.
public class NotificationsActivity extends AppCompatActivity {

    // Displays whether SMS permission is enabled or disabled.
    private TextView smsStatusTextView;

    // Stores the logged-in user's ID and username.
    private long userId;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display and loads the screen layout.
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notifications);

        // Retrieves the user's information from the previous screen.
        userId = getIntent().getLongExtra("USER_ID", -1);
        username = getIntent().getStringExtra("USERNAME");

        // Connects the buttons and status text to the layout elements.
        Button smsPermissionButton =
                findViewById(R.id.smsPermissionButton);
        Button backToHistoryButton =
                findViewById(R.id.backToHistoryButton);
        smsStatusTextView =
                findViewById(R.id.smsStatusTextView);

        // Requests SMS permission when the user presses the button.
        smsPermissionButton.setOnClickListener(v -> {

            // Checks whether Android has already granted SMS permission.
            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                // Displays Android's permission prompt to the user.
                requestPermissions(
                        new String[]{Manifest.permission.SEND_SMS},
                        100
                );

            } else {
                // Updates the displayed status if permission is already granted.
                updatePermissionStatus();

                // Informs the user that SMS permission is already enabled.
                Toast.makeText(this,
                        "SMS permission is already enabled.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Returns to the weight history screen.
        backToHistoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    NotificationsActivity.this,
                    WeightHistoryActivity.class);

            // Passes the user's information to preserve the login session.
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME", username);

            startActivity(intent);

            // Closes the notifications screen.
            finish();
        });

        // Adjusts screen padding to prevent content from overlapping
        // the device's status bar and navigation bar.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);

                    return insets;
                });
    }

    // Refreshes the permission status whenever the screen becomes active.
    @Override
    protected void onResume() {
        super.onResume();

        // Displays the current SMS permission status.
        updatePermissionStatus();
    }

    // Checks Android's permission setting and updates the status message.
    private void updatePermissionStatus() {

        // Prevents an error if the status text has not been initialized.
        if (smsStatusTextView == null) {
            return;
        }

        // Checks whether SMS permission has been granted.
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            // Displays a message when SMS permission is enabled.
            smsStatusTextView.setText(
                    "SMS notifications are enabled.");

        } else {
            // Explains that weight tracking still works without permission.
            smsStatusTextView.setText(
                    "SMS permission is disabled. "
                            + "Weight tracking will still work.");
        }
    }

    // Handles the result after Android displays the permission prompt.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        // Confirms that the result belongs to the SMS permission request.
        if (requestCode == 100) {

            // Checks Android's actual permission status after the response.
            updatePermissionStatus();

            // Displays a message based on whether permission was granted.
            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                // Confirms that SMS permission is now enabled.
                Toast.makeText(this,
                        "SMS permission enabled.",
                        Toast.LENGTH_SHORT).show();

            } else {
                // Explains that denying permission does not disable
                // the app's main weight-tracking features.
                Toast.makeText(this,
                        "SMS permission was denied. "
                                + "Weight tracking is still available.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}